#
BOA Example
The program is lexically correct about the SOFIA city 
#
main& {
	data {
		int FoundationYear$;
		real Area%, HDI%;
		string CountryName@;
	}
	code {
		FoundationYear$ = -7000;
		Area% = 492.0;
		HDI%=0.871;
		CountryName@ = 'Bulgary';
		print&(CountryName$);
	}
}
