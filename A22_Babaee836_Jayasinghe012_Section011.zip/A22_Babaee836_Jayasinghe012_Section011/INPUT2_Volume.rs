# BOA Example 3:
  volume of a sphere #

  Function main:() Begin
		r ::Float
 		pi = 3
		pi = 3.14
		r = input:()
		vol = 4.0 / 3.0 * pi * (r * r * r)
		println:(vol)
End	

