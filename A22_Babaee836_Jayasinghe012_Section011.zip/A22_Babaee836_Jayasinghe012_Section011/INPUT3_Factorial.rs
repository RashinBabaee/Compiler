# BOA Example 4:
  Testing numbers (ex: factorial) #

        f=1
        i=1
        println:("Write a number:")
        input:(n)
        While i<n Do 
            f = f * i
            i = i + 1
        End
        println:("Factorial:")
        println:(f)


