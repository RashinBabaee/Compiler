# Julius Example 2:
  The program is "lexically" correct
  and should not generate any error #

  Function main:() Begin
    println:("Hello world!")
	End