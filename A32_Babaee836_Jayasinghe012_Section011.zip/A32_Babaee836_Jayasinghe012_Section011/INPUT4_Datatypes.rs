#
BOA Example
The program is lexically correct about the SOFIA city 
#

Function main:() Begin
		foundationYear :: Int
		area :: Float, hdi :: Float
		countryName :: String
	

		foundationYear = -7000
		area = 492.0
		hdi=0.871
		countryName = "Bulgary"
		println:(countryName)
End		
