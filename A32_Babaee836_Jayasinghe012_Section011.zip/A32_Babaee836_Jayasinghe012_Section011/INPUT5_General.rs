# SOFIA Example
The program is "lexically" correct and should not generate any error (based on Platypus from Svillen Ranev) #

Function main:() Begin
		 i :: Int
		 a :: Float, sum008 :: Float
		 text :: String
	
		a= +1.2
		sum008 = 7.87050 
		input:(a,sum008)
		i=0
		While i < 32767 || i == 32767 Do
			i = i + 2
			a = a * i/0.5 
			sum008 = sum008 + a - 1 
		End

		If text == "" Then 
			text = "prog" * "ram"
		
		Else 
			text = text * "ram"

		End
		
		println:("\* This is a program -:)-<-<-- \*")
		println:(text)
		If text != "program" && sum008==8.0 || i>10 Then 
			println:(sum008)
			println:()
		
		Else 
		End

End